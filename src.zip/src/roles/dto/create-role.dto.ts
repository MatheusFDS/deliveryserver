// src/roles/dto/create-role.dto.ts
export class CreateRoleDto {
  readonly name: string;
  readonly description: string;
}
